require("dotenv").config();
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");

// importa a rota correta
const { userRoute } = require("./routes/userRoute");

const app = express();
app.use(cors());
app.use(express.json());

// rota de teste
app.get("/", (req, res) => {
  res.send("User Service is running");
});

// rotas de usuário
app.use("/user", userRoute);

// porta
const PORT = process.env.PORT || 3001;

// inicia o serviço
const start = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URL);
    console.log("User Service connected to MongoDB");

    app.listen(PORT, () => {
      console.log(`User Service running on port ${PORT}`);
    });

  } catch (err) {
    console.error("Database connection error:", err);
  }
};

start();
