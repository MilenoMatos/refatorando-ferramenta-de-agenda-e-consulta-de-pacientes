// models/userModel.js
const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    role: { 
      type: String, 
      enum: ["doctor", "patient"], 
      default: "patient" 
    },
    location: { type: String, required: true },
    specialty: { type: String, default: "None" }
  },
  { timestamps: true }
);

const Usermodel = mongoose.model("User", userSchema);

module.exports = { Usermodel };
