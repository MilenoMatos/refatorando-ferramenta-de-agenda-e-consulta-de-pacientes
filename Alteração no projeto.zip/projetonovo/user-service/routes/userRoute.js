// routes/userRoute.js
const express = require("express");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const fs = require("fs");
require("dotenv").config();
const { Usermodel } = require("../models/userModel");

const userRoute = express.Router();

/* ===========================
      GET all doctors
=========================== */
userRoute.get("/doctors", async (req, res) => {
  try {
    const allDoctor = await Usermodel.find({ role: "doctor" });
    res.json({ msg: "All doctors details", data: allDoctor });
  } catch (error) {
    console.log(error);
    res.json({ msg: "Error while getting doctors" });
  }
});

/* ===========================
  GET doctors by location
=========================== */
userRoute.get("/doctors/location/:location", async (req, res) => {
  const location = req.params.location;

  try {
    const allDoctor = await Usermodel.find({
      role: "doctor",
      location: { $regex: location, $options: "i" }
    });
    res.json({ msg: "Doctors by location", data: allDoctor });
  } catch (error) {
    console.log(error);
    res.json({ msg: "Error while getting doctors by location" });
  }
});

/* ===========================
  GET doctors by specialty
=========================== */
userRoute.get("/doctors/specialty/:value", async (req, res) => {
  const specialty = req.params.value;

  try {
    const allDoctor = await Usermodel.find({ role: "doctor", specialty });
    res.json({ msg: "Doctors by specialty", data: allDoctor });
  } catch (error) {
    console.log(error);
    res.json({ msg: "Error while getting doctors by specialty" });
  }
});

/* ===========================
        REGISTER
=========================== */
userRoute.post("/register", async (req, res) => {
  const { name, email, password, role, specialty, location } = req.body;

  try {
    const exists = await Usermodel.findOne({ email });
    if (exists) {
      return res.json({ msg: "User already registered" });
    }

    const hash = await bcrypt.hash(password, 5);

    const newUser = new Usermodel({
      name,
      email,
      password: hash,
      role,
      specialty: specialty || "None",
      location
    });

    await newUser.save();

    res.json({ msg: "User registered successfully" });
  } catch (error) {
    console.log(error);
    res.json({ msg: "Error registering user" });
  }
});

/* ===========================
           LOGIN
=========================== */
userRoute.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await Usermodel.findOne({ email });

    if (!user) {
      return res.json({ msg: "Register first" });
    }

    const match = await bcrypt.compare(password, user.password);

    if (!match) {
      return res.json({ msg: "Wrong credentials" });
    }

    const token = jwt.sign(
      { userId: user._id, role: user.role, email: user.email },
      process.env.KEY,
      { expiresIn: "24h" }
    );

    res.json({
      msg: "Login successful",
      token,
      role: user.role,
      name: user.name
    });
  } catch (error) {
    console.log(error);
    res.json({ msg: "Error logging in" });
  }
});

/* ===========================
           LOGOUT
=========================== */
userRoute.get("/logout", (req, res) => {
  const token = req.headers.authorization;

  try {
    const blacklist = JSON.parse(fs.readFileSync("./blacklist.json", "utf-8"));
    blacklist.push(token);
    fs.writeFileSync("./blacklist.json", JSON.stringify(blacklist));

    res.json({ msg: "Logout successful" });
  } catch (error) {
    console.log(error);
    res.json({ msg: "Error while logging out" });
  }
});

module.exports = { userRoute };
