const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
require("dotenv").config();

const { bookingRoute } = require("./routes/bookingRoute");

const app = express();
app.use(cors());
app.use(express.json());

// Criar pasta data caso não exista
const dataDir = path.join(__dirname, "data");
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir);
}

app.get("/", (req, res) => {
    res.send("Booking Service is running 📅");
});

// Registrar rotas
app.use("/booking", bookingRoute);

const PORT = process.env.PORT || 3002;
app.listen(PORT, () => console.log(`Booking Service rodando na porta ${PORT}`));
