const express = require("express");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");

const router = express.Router();

require("dotenv").config();

const BOOKINGS_FILE = path.join(__dirname, "..", "data", "bookings.json");

// Carregar agendamentos
function loadBookings() {
  try {
    const raw = fs.readFileSync(BOOKINGS_FILE, "utf-8");
    return JSON.parse(raw || "[]");
  } catch (err) {
    return [];
  }
}

// Salvar agendamentos
function saveBookings(list) {
  fs.writeFileSync(BOOKINGS_FILE, JSON.stringify(list, null, 2));
}

// Middleware para autenticação corrigido
function authBooking(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({ msg: "No token provided" });
  }

  // Esperado: "Bearer <token>"
  const parts = authHeader.split(" ");

  if (parts.length !== 2) {
    return res.status(401).json({ msg: "Token error" });
  }

  const [scheme, token] = parts;

  if (!/^Bearer$/i.test(scheme)) {
    return res.status(401).json({ msg: "Token malformatted" });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ msg: "Invalid token" });
  }
}

/* ============================
   Criar agendamento
   POST /booking/create
============================ */
router.post("/create", authBooking, (req, res) => {
  const { doctorId, date, time } = req.body;

  if (!doctorId || !date || !time) {
    return res.status(400).json({ msg: "Missing required fields" });
  }

  const bookings = loadBookings();

  const newBooking = {
    id: Date.now().toString(),
    patientId: req.user.userId,
    doctorId,
    date,
    time,
    status: "active"
  };

  bookings.push(newBooking);
  saveBookings(bookings);

  res.status(201).json({ msg: "Booking created", data: newBooking });
});

/* ============================
   Listar agendamentos do paciente
   GET /booking/my
============================ */
router.get("/my", authBooking, (req, res) => {
  const bookings = loadBookings();
  const list = bookings.filter(b => b.patientId === req.user.userId);
  res.json({ msg: "Your bookings", data: list });
});

/* ============================
   Listar agendamentos por médico
   GET /booking/doctor/:doctorId
============================ */
router.get("/doctor/:doctorId", (req, res) => {
  const doctorId = req.params.doctorId;
  const bookings = loadBookings();

  const list = bookings.filter(b => b.doctorId === doctorId);

  res.json({ msg: "Bookings for doctor", data: list });
});

/* ============================
   Cancelar agendamento
   DELETE /booking/cancel/:id
============================ */
router.delete("/cancel/:id", authBooking, (req, res) => {
  const bookingId = req.params.id;

  let bookings = loadBookings();
  const booking = bookings.find(b => b.id === bookingId);

  if (!booking) {
    return res.status(404).json({ msg: "Booking not found" });
  }

  // Apenas o dono cancela
  if (booking.patientId !== req.user.userId) {
    return res.status(403).json({ msg: "Not allowed" });
  }

  booking.status = "cancelled";
  saveBookings(bookings);

  res.json({ msg: "Booking cancelled", data: booking });
});

module.exports = { bookingRoute: router };
