const express = require("express");
const cors = require("cors");
const { createProxyMiddleware } = require("http-proxy-middleware");

const app = express();
app.use(cors());

// ⚠ NÃO USAR express.json() AQUI!!
// Ele destrói o body e quebra POST/PUT/PATCH no proxy.

// USER SERVICE
app.use(
  "/user",
  createProxyMiddleware({
    target: "http://localhost:3001",
    changeOrigin: true,
    // NÃO reescreve nada — mantém /user/register, /user/doctors etc
    pathRewrite: { "^/user": "" },

    // 👇 ESSENCIAL para POST funcionar
    proxyTimeout: 5000,
    timeout: 5000,
    ws: false,
  })
);

// BOOKING SERVICE
app.use(
  "/booking",
  createProxyMiddleware({
    target: "http://localhost:3002",
    changeOrigin: true,
    pathRewrite: { "^/booking": "" },
    proxyTimeout: 5000,
    timeout: 5000,
    ws: false,
  })
);

app.get("/", (req, res) => {
  res.send("API Gateway funcionando 🚀");
});

app.listen(3000, () =>
  console.log("API Gateway rodando na porta 3000")
);
