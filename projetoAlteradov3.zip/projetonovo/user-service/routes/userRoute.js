const express = require("express");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");

const router = express.Router();

const USERS_FILE = path.join(__dirname, "..", "data", "users.json");
const BLACKLIST_FILE = path.join(__dirname, "..", "blacklist.json");

function loadUsers() {
  try {
    const raw = fs.readFileSync(USERS_FILE, "utf-8");
    return JSON.parse(raw || "[]");
  } catch (err) {
    return [];
  }
}

function saveUsers(users) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

function loadBlacklist() {
  try {
    const raw = fs.readFileSync(BLACKLIST_FILE, "utf-8");
    return JSON.parse(raw || "[]");
  } catch (err) {
    return [];
  }
}

function saveBlacklist(list) {
  fs.writeFileSync(BLACKLIST_FILE, JSON.stringify(list, null, 2));
}

/* ===========================
   GET all doctors
   GET /user/doctors
=========================== */
router.get("/doctors", (req, res) => {
  const users = loadUsers();
  const doctors = users.filter((u) => u.role === "doctor");
  res.json({ msg: "All doctors", data: doctors });
});

/* ===========================
   GET doctors by location
   GET /user/doctors/location/:location
=========================== */
router.get("/doctors/location/:location", (req, res) => {
  const users = loadUsers();
  const location = req.params.location.toLowerCase();
  const doctors = users.filter(
    (u) => u.role === "doctor" && (u.location || "").toLowerCase().includes(location)
  );
  res.json({ msg: "Doctors by location", data: doctors });
});

/* ===========================
   GET doctors by specialty
   GET /user/doctors/specialty/:value
=========================== */
router.get("/doctors/specialty/:value", (req, res) => {
  const users = loadUsers();
  const value = req.params.value.toLowerCase();
  const doctors = users.filter(
    (u) => u.role === "doctor" && ((u.specialty || "").toLowerCase() === value)
  );
  res.json({ msg: "Doctors by specialty", data: doctors });
});

/* ===========================
   REGISTER
   POST /user/register
   body: { name, email, password, role, specialty, location }
=========================== */
router.post("/register", async (req, res) => {
  try {
    const { name, email, password, role, specialty, location } = req.body;
    if (!name || !email || !password || !location) {
      return res.status(400).json({ msg: "Missing required fields (name,email,password,location)" });
    }

    const users = loadUsers();
    if (users.some((u) => u.email === email)) {
      return res.status(409).json({ msg: "Email already registered" });
    }

    const hash = await bcrypt.hash(password, 8);
    const newUser = {
      id: Date.now().toString(),
      name,
      email,
      password: hash,
      role: role || "patient",
      specialty: specialty || "None",
      location
    };

    users.push(newUser);
    saveUsers(users);

    // do not return password
    const { password: _, ...userSafe } = newUser;
    res.status(201).json({ msg: "User registered", user: userSafe });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Error registering user" });
  }
});

/* ===========================
   LOGIN
   POST /user/login
   body: { email, password }
=========================== */
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const users = loadUsers();
    const user = users.find((u) => u.email === email);
    if (!user) return res.status(404).json({ msg: "Register first" });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ msg: "Wrong credentials" });

    const token = jwt.sign(
      { userId: user.id, role: user.role, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: "24h" }
    );

    res.json({ msg: "Login success", token, role: user.role, name: user.name });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Error logging in" });
  }
});

/* ===========================
   LOGOUT
   GET /user/logout
   header: Authorization: <token>
=========================== */
router.get("/logout", (req, res) => {
  try {
    const auth = req.headers.authorization;
    if (!auth) return res.status(400).json({ msg: "No token provided" });

    const list = loadBlacklist();
    list.push(auth);
    saveBlacklist(list);
    res.json({ msg: "Logout successful" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Error logging out" });
  }
});

/* ===========================
   Middleware example to protect routes (exports)
=========================== */
function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ msg: "No token" });

  const black = loadBlacklist();
  if (black.includes(auth)) return res.status(403).json({ msg: "Token blacklisted" });

  try {
    const payload = jwt.verify(auth, process.env.JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ msg: "Invalid token" });
  }
}

module.exports = { userRoute: router, authMiddleware };
