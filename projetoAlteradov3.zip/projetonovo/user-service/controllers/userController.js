const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");

const { loadUsers, saveUsers } = require("../models/userModel");

const BLACKLIST_FILE = path.join(__dirname, "..", "blacklist.json");

function loadBlacklist() {
  try {
    const raw = fs.readFileSync(BLACKLIST_FILE, "utf8");
    return JSON.parse(raw || "[]");
  } catch (err) {
    return [];
  }
}

function saveBlacklist(list) {
  fs.writeFileSync(BLACKLIST_FILE, JSON.stringify(list, null, 2));
}

module.exports = {

  // ======================================================
  // LISTAR MÉDICOS
  // ======================================================
  getDoctors(req, res) {
    const users = loadUsers();
    const doctors = users.filter(u => u.role === "doctor");
    res.json(doctors);
  },

  getDoctorsByLocation(req, res) {
    const location = req.params.location.toLowerCase();
    const users = loadUsers();
    const doctors = users.filter(
      u => u.role === "doctor" &&
      (u.location || "").toLowerCase().includes(location)
    );
    res.json(doctors);
  },

  getDoctorsBySpecialty(req, res) {
    const value = req.params.value.toLowerCase();
    const users = loadUsers();
    const doctors = users.filter(
      u => u.role === "doctor" &&
      (u.specialty || "").toLowerCase().includes(value)
    );
    res.json(doctors);
  },

  // ======================================================
  // REGISTRO
  // ======================================================
  async register(req, res) {
    try {
      const { name, email, password, role, specialty, location } = req.body;

      if (!name || !email || !password || !location) {
        return res.status(400).json({ msg: "Campos obrigatórios faltando" });
      }

      const users = loadUsers();

      if (users.some(u => u.email === email)) {
        return res.status(409).json({ msg: "Email já cadastrado" });
      }

      const hash = await bcrypt.hash(password, 8);

      const newUser = {
        id: Date.now().toString(),
        name,
        email,
        password: hash,
        role: role || "patient",
        specialty: specialty || "Not specified",
        location
      };

      users.push(newUser);
      saveUsers(users);

      const { password: _, ...safeUser } = newUser;
      res.status(201).json({ msg: "Usuário registrado", user: safeUser });

    } catch (err) {
      res.status(500).json({ msg: "Erro ao registrar usuário" });
    }
  },

  // ======================================================
  // LOGIN
  // ======================================================
  async login(req, res) {
    const { email, password } = req.body;

    const users = loadUsers();
    const user = users.find(u => u.email === email);

    if (!user) return res.status(404).json({ msg: "Usuário não encontrado" });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ msg: "Senha incorreta" });

    const token = jwt.sign(
      { userId: user.id, role: user.role, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: "24h" }
    );

    res.json({ msg: "Login bem-sucedido", token, role: user.role, name: user.name });
  },

  // ======================================================
  // LOGOUT
  // ======================================================
  logout(req, res) {
    const token = req.headers.authorization;

    if (!token) return res.status(400).json({ msg: "Token não enviado" });

    const blacklist = loadBlacklist();
    blacklist.push(token);
    saveBlacklist(blacklist);

    res.json({ msg: "Logout realizado" });
  }
};
