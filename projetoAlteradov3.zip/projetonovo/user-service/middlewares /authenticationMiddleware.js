const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");

const BLACKLIST_FILE = path.join(__dirname, "..", "blacklist.json");
function loadBlacklist() {
  try {
    const raw = fs.readFileSync(BLACKLIST_FILE, "utf8");
    return JSON.parse(raw || "[]");
  } catch (err) {
    return [];
  }
}

module.exports = function authMiddleware(req, res, next) {
  const token = req.headers.authorization;

  if (!token)
    return res.status(401).json({ msg: "Token não informado" });

  const blacklist = loadBlacklist();
  if (blacklist.includes(token))
    return res.status(403).json({ msg: "Token expirado ou inválido (logout realizado)" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;  // injeta o usuário autenticado
    next();
  } catch (err) {
    return res.status(401).json({ msg: "Token inválido" });
  }
};
