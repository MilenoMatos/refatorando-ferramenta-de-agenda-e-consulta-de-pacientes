const express = require("express");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const { userRoute } = require("./routes/userRoute");

const app = express();
app.use(cors());
app.use(express.json());

// criar pasta /data automaticamente se não existir
const fs = require("fs");
const dataDir = path.join(__dirname, "data");
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir);
}

app.get("/", (req, res) => {
  res.send("User Service is running 🎉");
});

// rotas reais do microserviço
app.use("/", userRoute);

const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
  console.log(`User Service rodando na porta ${PORT}`);
});
